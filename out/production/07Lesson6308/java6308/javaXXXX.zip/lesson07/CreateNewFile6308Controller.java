package java6308.lesson07;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class CreateNewFile6308Controller {

    @FXML
    private TextField tfFilename;

    @FXML
    private Label lblMessage;

    @FXML
    void listAll(ActionEvent event) {
        tfFilename.focusedProperty().addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {

            }
        });

    }

}

