package java6308.lesson07;

import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.event.EventType;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class ListFile6308Controller {

    @FXML
    private ListView<String> lvFiles;//显示目录

    @FXML
    private TextField tfDir;//输入目录地址

    @FXML
    private Label lblCount;//统计子目录个数，文件个数
    ObservableList<String> items;

    //对输入框的监听
    @FXML
    void listAll(ActionEvent event) {
        items=lvFiles.getItems();
        items.clear();
        File file = new File(tfDir.getText());
        finalize(file);
    }

    private void finalize(File file) {
        if (file.exists()) {
            File[] files = file.listFiles();

            for (File me : files) {
                if(me.isDirectory()){
                    items.add("文件夹,"+me.getName()+",");
                }else{
                    items.add(me.getName()+",");
                }
            }
        }
    }
}